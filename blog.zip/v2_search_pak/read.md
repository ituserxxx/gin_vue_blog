

cd gin-server

go build -o blog_api_v2 main.go

cd admin
npm run build:prod

cd vue-front
npm run build


cd v2_search_pak

cp -r ../vue-front/dist front
cp -r ../admin/dist admin